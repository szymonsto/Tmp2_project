#include "MKL05Z4.h"


void pitInit(void);

void PIT_IRQHandler(void);

void setPit(uint32_t time_val);