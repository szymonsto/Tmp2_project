#include "MKL05Z4.h"
void UART0_Init(void);

void uart_sendCh(uint8_t data);
	